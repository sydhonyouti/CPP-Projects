#include <iostream>
#include <mpi.h>
#include <string>
#include "my_matrix.hpp"
#include "laplace.hpp"
using namespace my;
using std::cin;
using std::cout;

int main(int DataArg1, char* DataArg2[])
{
	my::laplace Laplace;
	Laplace.init(DataArg1, DataArg2);
	Laplace.RunLaplace();
	MPI_Finalize();
}