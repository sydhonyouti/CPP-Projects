I worked with Chad Morris on the project.

One of the biggest struggles was trying to understand how to start the project.
We both understood what the project was asking but we couldn't figure out how
to start or what to include. We also used your matrix class you had provided.

Conrad and Mason helped us both by describing to us how the project actually worked
and where to start. Without them I probably wouldn't have been able to start.