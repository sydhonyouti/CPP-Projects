#ifndef MY_MATRIX_HPP
#define MY_MATRIX_HPP

#include <vector>
#include <ostream>
#include <iomanip>

namespace my {

	template <typename T>
	class matrix {
		std::vector<T> _elements;
		size_t _num_rows;
		size_t _num_cols;

	public:

		matrix()
			: _num_rows(0), _num_cols(0) {
		}

		matrix(size_t num_rows, size_t num_cols, T init = T())
			: _num_rows(num_rows), _num_cols(num_cols), _elements(num_rows* num_cols, init) {
		}

		size_t num_rows() const {
			return _num_rows;
		}

		size_t num_cols() const {
			return _num_cols;
		}

		void resize(size_t num_rows, size_t num_cols, T init = T()) {
			_num_rows = num_rows;
			_num_cols = num_cols;
			_elements.resize(num_rows * num_cols, init);
		}

		T* operator [](size_t i) {
			return _elements.data() + _num_cols * i;
		}

		const T* operator [](size_t i) const {
			return _elements.data() + _num_cols * i;
		}

		T* data() {
			return _elements.data();
		}

		const T* data() const {
			return _elements.data();
		}

		friend std::ostream& operator <<(std::ostream& os, const matrix<T>& m) {
			for (size_t r = 0; r < m._num_rows; ++r) {
				for (size_t c = 0; c < m._num_cols; ++c) {
					if (c != 0) os << ' ';
					os << std::setw(6) << m._elements[r * m._num_cols + c];
				}
				os << '\n';
			}
			return os;
		}

		friend std::istream& operator >>(std::istream& is, matrix<T>& m) {
			for (size_t r = 0; r < m._num_rows; ++r) {
				for (size_t c = 0; c < m._num_cols; ++c) {
					is >> m._elements[r * m._num_cols + c];
				}
			}
			return is;
		}
	};
}
#endif